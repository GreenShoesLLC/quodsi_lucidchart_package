"use strict";
// src/services/lucidSimulationJobSubmissionService.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LucidSimulationJobSubmissionService = void 0;
const batch_1 = require("@azure/batch");
const attempt_1 = require("@lifeomic/attempt");
const batchErrors_1 = require("./errors/batchErrors");
class LucidSimulationJobSubmissionService {
    constructor(config) {
        this.jobRetryOptions = {
            maxAttempts: 3,
            factor: 2,
            timeout: 30000,
            handleError: (error, context) => __awaiter(this, void 0, void 0, function* () {
                console.warn('[BatchService] Job creation retry:', {
                    attempt: context.attemptNum,
                    error: error.message,
                    code: error.code
                });
            })
        };
        this.taskRetryOptions = {
            maxAttempts: 3,
            factor: 2,
            timeout: 30000,
            handleError: (error, context) => __awaiter(this, void 0, void 0, function* () {
                console.warn('[BatchService] Task submission retry:', {
                    attempt: context.attemptNum,
                    error: error.message,
                    code: error.code
                });
            })
        };
        try {
            // Validate configuration
            if (!config.batchAccountUrl)
                throw new batchErrors_1.BatchConfigurationError("BatchAccountUrl is not configured.", "BatchAccountUrl");
            if (!config.batchAccountName)
                throw new batchErrors_1.BatchConfigurationError("BatchAccountName is not configured.", "BatchAccountName");
            if (!config.batchAccountKey)
                throw new batchErrors_1.BatchConfigurationError("BatchAccountKey is not configured.", "BatchAccountKey");
            if (!config.poolId)
                throw new batchErrors_1.BatchConfigurationError("BatchPoolId is not configured.", "BatchPoolId");
            // Initialize client
            const credentials = new batch_1.BatchSharedKeyCredentials(config.batchAccountName, config.batchAccountKey);
            this.batchClient = new batch_1.BatchServiceClient(credentials, config.batchAccountUrl);
            this.poolId = config.poolId;
            this.defaultApplicationId = config.defaultApplicationId || "LucidQuodsim";
            this.defaultAppVersion = config.defaultAppVersion || "1.0";
            console.log('[BatchService] Initialized with pool:', this.poolId);
        }
        catch (error) {
            if (error instanceof batchErrors_1.BatchConfigurationError) {
                throw error;
            }
            throw new batchErrors_1.BatchConfigurationError("Failed to initialize batch configuration.", "Unknown", error);
        }
    }
    isTransientError(error) {
        if (!error.code)
            return false;
        return [
            'OperationTimedOut',
            'ServerBusy',
            'ServiceUnavailable',
            'RequestRateTooLarge'
        ].includes(error.code);
    }
    submitJob(documentId, pageId, userId, applicationId, appVersion) {
        return __awaiter(this, void 0, void 0, function* () {
            applicationId = applicationId || this.defaultApplicationId;
            appVersion = appVersion || this.defaultAppVersion;
            console.log('[BatchService] Starting job submission for document:', documentId);
            try {
                const jobId = `Job-${crypto.randomUUID()}`;
                const taskId = `Task-${crypto.randomUUID()}`;
                // Create and commit job with retry
                yield (0, attempt_1.retry)(() => __awaiter(this, void 0, void 0, function* () {
                    const poolInfo = {
                        poolId: this.poolId
                    };
                    const jobParams = {
                        id: jobId,
                        poolInfo: poolInfo
                    };
                    yield this.batchClient.job.add(jobParams);
                }), this.jobRetryOptions);
                // Create and submit task with retry
                yield (0, attempt_1.retry)(() => __awaiter(this, void 0, void 0, function* () {
                    const appPackageEnvVar = `AZ_BATCH_APP_PACKAGE_${applicationId.toLowerCase()}_${appVersion.replace(".", "_")}`;
                    const taskCommandLine = `/bin/bash -c "source $AZ_BATCH_NODE_STARTUP_DIR/wd/batch_env/bin/activate && python3 -m pip list && cd $${appPackageEnvVar} && python3 -m quodsim_runner.lucidchart.cli --document-id ${documentId} --page-id ${pageId} --user-id ${userId}"`;
                    const taskParams = {
                        id: taskId,
                        commandLine: taskCommandLine,
                        // Add environment settings here:
                        environmentSettings: [
                            { name: "BATCH_ACCOUNT_NAME", value: process.env.BatchAccountName || "" },
                            { name: "BATCH_ACCOUNT_KEY", value: process.env.BatchAccountKey || "" },
                            { name: "BATCH_URL", value: process.env.BatchAccountUrl || "" }
                        ]
                    };
                    yield this.batchClient.task.add(jobId, taskParams);
                }), this.taskRetryOptions);
                console.log('[BatchService] Successfully submitted job with task:', { jobId, taskId });
                return `Job '${jobId}' with task '${taskId}' submitted successfully.`;
            }
            catch (error) {
                if (error.code === 'JobExists') {
                    throw new batchErrors_1.BatchJobCreationError("Job already exists", '', error);
                }
                if (error.code) {
                    throw new batchErrors_1.BatchJobCreationError(`Batch error: ${error.message}`, '', error);
                }
                throw new batchErrors_1.BatchConfigurationError("An unexpected error occurred while submitting the Batch job.", "Unknown", error);
            }
        });
    }
}
exports.LucidSimulationJobSubmissionService = LucidSimulationJobSubmissionService;
//# sourceMappingURL=lucidSimulationJobSubmissionService.js.map