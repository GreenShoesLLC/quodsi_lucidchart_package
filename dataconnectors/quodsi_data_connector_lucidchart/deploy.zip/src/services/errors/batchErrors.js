"use strict";
// src/services/errors/batchErrors.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchJobCreationError = exports.BatchConfigurationError = void 0;
class BatchConfigurationError extends Error {
    constructor(message, configurationKey, originalError) {
        super(message);
        this.configurationKey = configurationKey;
        this.originalError = originalError;
        this.name = 'BatchConfigurationError';
    }
}
exports.BatchConfigurationError = BatchConfigurationError;
class BatchJobCreationError extends Error {
    constructor(message, jobId, batchError // Azure Batch error details
    ) {
        super(message);
        this.jobId = jobId;
        this.batchError = batchError;
        this.name = 'BatchJobCreationError';
    }
}
exports.BatchJobCreationError = BatchJobCreationError;
//# sourceMappingURL=batchErrors.js.map