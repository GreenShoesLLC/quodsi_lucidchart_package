"use strict";
// src/services/azureStorageService.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureStorageService = void 0;
const storage_blob_1 = require("@azure/storage-blob");
const attempt_1 = require("@lifeomic/attempt");
class AzureStorageService {
    constructor(connectionString) {
        console.log('[AzureStorageService] Initializing service');
        this.blobServiceClient = storage_blob_1.BlobServiceClient.fromConnectionString(connectionString);
        console.log('[AzureStorageService] BlobServiceClient initialized:', {
            url: this.blobServiceClient.url,
            accountName: this.blobServiceClient.accountName
        });
        // Optimize exists check for speed
        this.existsRetryOptions = {
            maxAttempts: 2,
            initialDelay: 100,
            factor: 2,
            timeout: 3000,
            handleError: (error, context) => __awaiter(this, void 0, void 0, function* () {
                console.warn('[AzureStorageService] Container check retry:', {
                    attempt: context.attemptNum,
                    error: error.message
                });
            })
        };
        // Optimize blob retrieval
        this.blobRetryOptions = {
            maxAttempts: 2,
            initialDelay: 200,
            factor: 2,
            timeout: 5000,
            handleError: (error, context) => __awaiter(this, void 0, void 0, function* () {
                console.warn('[AzureStorageService] Blob retrieval retry:', {
                    attempt: context.attemptNum,
                    error: error.message
                });
            })
        };
        // Configure upload retry options
        this.uploadRetryOptions = {
            maxAttempts: 3,
            initialDelay: 200,
            factor: 2,
            timeout: 10000,
            handleError: (error, context) => __awaiter(this, void 0, void 0, function* () {
                console.warn('[AzureStorageService] Upload retry:', {
                    attempt: context.attemptNum,
                    error: error.message
                });
            })
        };
    }
    containerExists(containerName) {
        return __awaiter(this, void 0, void 0, function* () {
            const startTime = Date.now();
            try {
                const containerClient = this.blobServiceClient.getContainerClient(containerName);
                const exists = yield (0, attempt_1.retry)(() => __awaiter(this, void 0, void 0, function* () {
                    return yield containerClient.exists();
                }), this.existsRetryOptions);
                console.log('[AzureStorageService] Container check:', {
                    containerName,
                    exists,
                    durationMs: Date.now() - startTime
                });
                return exists;
            }
            catch (error) {
                console.error('[AzureStorageService] Container check failed:', {
                    containerName,
                    error: error.message,
                    durationMs: Date.now() - startTime
                });
                return false;
            }
        });
    }
    getBlobContent(containerName, blobName) {
        return __awaiter(this, void 0, void 0, function* () {
            const startTime = Date.now();
            try {
                const containerClient = this.blobServiceClient.getContainerClient(containerName);
                const blobClient = containerClient.getBlobClient(blobName);
                // Check existence and get content in parallel if possible
                const [exists, properties] = yield Promise.all([
                    blobClient.exists(),
                    blobClient.getProperties().catch(() => null)
                ]);
                if (!exists) {
                    return null;
                }
                const content = yield (0, attempt_1.retry)(() => __awaiter(this, void 0, void 0, function* () {
                    const downloadStart = Date.now();
                    const response = yield blobClient.download();
                    const content = yield this.streamToBuffer(response.readableStreamBody);
                    console.log('[AzureStorageService] Blob download:', {
                        size: content.length,
                        downloadMs: Date.now() - downloadStart
                    });
                    return content.toString();
                }), this.blobRetryOptions);
                console.log('[AzureStorageService] Blob retrieved:', {
                    containerName,
                    blobName,
                    contentLength: content.length,
                    contentType: properties === null || properties === void 0 ? void 0 : properties.contentType,
                    durationMs: Date.now() - startTime
                });
                return content;
            }
            catch (error) {
                console.error('[AzureStorageService] Blob retrieval failed:', {
                    containerName,
                    blobName,
                    error: error.message,
                    durationMs: Date.now() - startTime
                });
                return null;
            }
        });
    }
    uploadBlobContent(containerName, blobName, content) {
        return __awaiter(this, void 0, void 0, function* () {
            const startTime = Date.now();
            try {
                const containerClient = this.blobServiceClient.getContainerClient(containerName);
                // Ensure container exists
                if (!(yield containerClient.exists())) {
                    yield containerClient.create();
                    console.log('[AzureStorageService] Container created:', { containerName });
                }
                const blockBlobClient = containerClient.getBlockBlobClient(blobName);
                const contentBuffer = Buffer.from(content);
                const uploadResult = yield (0, attempt_1.retry)(() => __awaiter(this, void 0, void 0, function* () {
                    const uploadStart = Date.now();
                    const result = yield blockBlobClient.uploadData(contentBuffer, {
                        blobHTTPHeaders: {
                            blobContentType: 'application/json'
                        }
                    });
                    console.log('[AzureStorageService] Blob upload:', {
                        etag: result.etag,
                        uploadMs: Date.now() - uploadStart
                    });
                    return result;
                }), this.uploadRetryOptions);
                console.log('[AzureStorageService] Upload completed:', {
                    containerName,
                    blobName,
                    contentLength: content.length,
                    durationMs: Date.now() - startTime,
                    etag: uploadResult.etag
                });
                return true;
            }
            catch (error) {
                console.error('[AzureStorageService] Upload failed:', {
                    containerName,
                    blobName,
                    error: error.message,
                    durationMs: Date.now() - startTime
                });
                return false;
            }
        });
    }
    streamToBuffer(readableStream) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                const chunks = [];
                readableStream.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
                readableStream.on('end', () => resolve(Buffer.concat(chunks)));
                readableStream.on('error', reject);
            });
        });
    }
}
exports.AzureStorageService = AzureStorageService;
//# sourceMappingURL=azureStorageService.js.map