"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateLucidRequest = exports.createDataConnector = void 0;
const lucid_extension_sdk_1 = require("lucid-extension-sdk");
const crypto = require("crypto");
const simulateAction_1 = require("../actions/simulateAction");
const getActivityUtilizationAction_1 = require("../actions/getActivityUtilizationAction");
const pollAction_1 = require("../actions/pollAction");
const patchAction_1 = require("../actions/patchAction");
const hardRefreshAction_1 = require("../actions/hardRefreshAction");
const importSimulationResultsAction_1 = require("../actions/importSimulationResultsAction");
const saveAndSubmitSimulationAction_1 = require("../actions/saveAndSubmitSimulationAction");
const uploadModelDefinitionAction_1 = require("../actions/uploadModelDefinitionAction");
const submitSimulationJobAction_1 = require("../actions/submitSimulationJobAction");
const createDataConnector = () => {
    const client = new lucid_extension_sdk_1.DataConnectorClient({ crypto, Buffer });
    return new lucid_extension_sdk_1.DataConnector(client)
        .defineAsynchronousAction("Simulate", simulateAction_1.simulateAction)
        .defineAsynchronousAction("GetActivityUtilization", getActivityUtilizationAction_1.getActivityUtilizationAction)
        .defineAsynchronousAction("Poll", pollAction_1.pollAction)
        .defineAction("Patch", patchAction_1.patchAction)
        .defineAsynchronousAction("HardRefresh", hardRefreshAction_1.hardRefreshAction)
        .defineAsynchronousAction("ImportSimulationResults", importSimulationResultsAction_1.importSimulationResultsAction)
        .defineAsynchronousAction("SaveAndSubmitSimulation", saveAndSubmitSimulationAction_1.saveAndSubmitSimulationAction)
        .defineAsynchronousAction("UploadModelDefinition", uploadModelDefinitionAction_1.uploadModelDefinitionAction)
        .defineAsynchronousAction("SubmitSimulationJob", submitSimulationJobAction_1.submitSimulationJobAction);
};
exports.createDataConnector = createDataConnector;
const validateLucidRequest = (headers, body) => __awaiter(void 0, void 0, void 0, function* () {
    // We'll implement proper validation later
    return true;
});
exports.validateLucidRequest = validateLucidRequest;
//# sourceMappingURL=dataConnectorUtils.js.map