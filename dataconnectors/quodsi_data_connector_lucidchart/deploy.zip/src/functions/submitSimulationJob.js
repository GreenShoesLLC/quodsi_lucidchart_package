"use strict";
// src/functions/submitSimulationJob.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitSimulationJob = void 0;
const functions_1 = require("@azure/functions");
const lucidSimulationJobSubmissionService_1 = require("../services/lucidSimulationJobSubmissionService");
const batchErrors_1 = require("../services/errors/batchErrors");
function submitSimulationJob(request, context) {
    return __awaiter(this, void 0, void 0, function* () {
        const metrics = {
            startTime: Date.now(),
            batchServiceInitDuration: 0,
            batchSubmitDuration: 0
        };
        const requestId = context.invocationId;
        context.log(`[${requestId}] Starting submitSimulationJob`);
        try {
            // Log request headers
            context.log(`[${requestId}] Request headers:`, {
                contentType: request.headers.get('content-type'),
                contentLength: request.headers.get('content-length'),
                authorization: request.headers.has('authorization') ? 'Present' : 'Missing'
            });
            // Parse and validate request body
            context.log(`[${requestId}] Attempting to parse request body`);
            const requestBody = yield request.json();
            const { documentId, pageId, userId, applicationId, appVersion } = requestBody;
            // Log validation check results
            context.log(`[${requestId}] Request body validation:`, {
                hasDocumentId: !!documentId,
                hasPageId: !!pageId,
                hasUserId: !!userId,
                hasApplicationId: !!applicationId,
                hasAppVersion: !!appVersion,
                applicationId: applicationId || 'Using default',
                appVersion: appVersion || 'Using default'
            });
            if (!documentId || !pageId || !userId) {
                context.log(`[${requestId}] Error: Missing required fields in request body`, {
                    missingFields: {
                        documentId: !documentId,
                        pageId: !pageId,
                        userId: !userId
                    }
                });
                return {
                    status: 400,
                    jsonBody: { message: "Missing required fields: documentId, pageId, or userId" }
                };
            }
            // Validate batch service configuration
            context.log(`[${requestId}] Validating batch service configuration`);
            const batchConfigValidation = {
                hasBatchAccountUrl: !!process.env.BatchAccountUrl,
                hasBatchAccountName: !!process.env.BatchAccountName,
                hasBatchAccountKey: !!process.env.BatchAccountKey,
                hasPoolId: !!process.env.BatchPoolId,
                hasDefaultApplicationId: !!process.env.DefaultApplicationId,
                hasDefaultAppVersion: !!process.env.DefaultAppVersion
            };
            context.log(`[${requestId}] Batch configuration status:`, batchConfigValidation);
            // Initialize batch service
            const batchInitStart = Date.now();
            context.log(`[${requestId}] Initializing batch service`);
            const batchService = new lucidSimulationJobSubmissionService_1.LucidSimulationJobSubmissionService({
                batchAccountUrl: process.env.BatchAccountUrl,
                batchAccountName: process.env.BatchAccountName,
                batchAccountKey: process.env.BatchAccountKey,
                poolId: process.env.BatchPoolId,
                defaultApplicationId: process.env.DefaultApplicationId,
                defaultAppVersion: process.env.DefaultAppVersion
            });
            metrics.batchServiceInitDuration = Date.now() - batchInitStart;
            context.log(`[${requestId}] Batch service initialized`, {
                duration: `${metrics.batchServiceInitDuration}ms`
            });
            // Submit the job
            const submitStart = Date.now();
            context.log(`[${requestId}] Submitting job to batch service`, {
                documentId,
                pageId,
                userId,
                applicationId: applicationId || 'default',
                appVersion: appVersion || 'default'
            });
            const result = yield batchService.submitJob(documentId, pageId, userId, applicationId, appVersion);
            metrics.batchSubmitDuration = Date.now() - submitStart;
            // Extract jobId and taskId from result message
            const jobIdMatch = result.match(/Job '([^']+)'/);
            const taskIdMatch = result.match(/task '([^']+)'/);
            context.log(`[${requestId}] Job submission completed`, {
                submitDuration: `${metrics.batchSubmitDuration}ms`,
                jobId: jobIdMatch === null || jobIdMatch === void 0 ? void 0 : jobIdMatch[1],
                taskId: taskIdMatch === null || taskIdMatch === void 0 ? void 0 : taskIdMatch[1],
                result
            });
            const response = {
                message: result,
                jobId: jobIdMatch === null || jobIdMatch === void 0 ? void 0 : jobIdMatch[1],
                taskId: taskIdMatch === null || taskIdMatch === void 0 ? void 0 : taskIdMatch[1]
            };
            // Log performance metrics
            const totalDuration = Date.now() - metrics.startTime;
            context.log(`[${requestId}] Operation completed successfully`, {
                totalDuration: `${totalDuration}ms`,
                batchServiceInitDuration: `${metrics.batchServiceInitDuration}ms`,
                batchSubmitDuration: `${metrics.batchSubmitDuration}ms`,
                documentId,
                pageId,
                userId,
                jobId: response.jobId,
                taskId: response.taskId,
                performanceBreakdown: {
                    batchServiceInit: Math.round((metrics.batchServiceInitDuration / totalDuration) * 100) + '%',
                    batchSubmit: Math.round((metrics.batchSubmitDuration / totalDuration) * 100) + '%',
                    other: Math.round(((totalDuration - metrics.batchServiceInitDuration - metrics.batchSubmitDuration) / totalDuration) * 100) + '%'
                }
            });
            return {
                status: 200,
                jsonBody: response
            };
        }
        catch (error) {
            const errorDuration = Date.now() - metrics.startTime;
            // Base error info
            const errorInfo = {
                type: error.constructor.name,
                message: error instanceof Error ? error.message : "Unknown error",
                stack: error instanceof Error ? error.stack : undefined,
                metrics: {
                    totalDuration: `${errorDuration}ms`,
                    batchServiceInitDuration: `${metrics.batchServiceInitDuration}ms`,
                    batchSubmitDuration: `${metrics.batchSubmitDuration}ms`
                }
            };
            if (error instanceof batchErrors_1.BatchConfigurationError) {
                context.log(`[${requestId}] Batch configuration error after ${errorDuration}ms:`, Object.assign(Object.assign({}, errorInfo), { configurationKey: error.configurationKey, phase: 'batch-configuration' }));
                return {
                    status: 500,
                    jsonBody: {
                        message: "Batch configuration error",
                        details: {
                            configurationKey: error.configurationKey,
                            message: error.message
                        }
                    }
                };
            }
            if (error instanceof batchErrors_1.BatchJobCreationError) {
                context.log(`[${requestId}] Batch job creation error after ${errorDuration}ms:`, Object.assign(Object.assign({}, errorInfo), { jobId: error.jobId, batchError: error.batchError, phase: 'batch-job-creation' }));
                return {
                    status: 500,
                    jsonBody: {
                        message: "Failed to create batch job",
                        details: {
                            jobId: error.jobId,
                            batchError: error.batchError,
                            message: error.message
                        }
                    }
                };
            }
            context.log(`[${requestId}] Unexpected error after ${errorDuration}ms:`, Object.assign(Object.assign({}, errorInfo), { phase: 'unknown' }));
            return {
                status: 500,
                jsonBody: {
                    message: "Unexpected error: " + (error instanceof Error ? error.message : "Unknown error")
                }
            };
        }
    });
}
exports.submitSimulationJob = submitSimulationJob;
functions_1.app.http("submitSimulationJob", {
    methods: ["POST"],
    authLevel: "anonymous",
    route: "simulation/submit",
    handler: submitSimulationJob
});
//# sourceMappingURL=submitSimulationJob.js.map