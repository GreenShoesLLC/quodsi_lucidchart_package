"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataConnectorHttpTrigger = void 0;
const functions_1 = require("@azure/functions");
const dataConnectorUtils_1 = require("../utils/dataConnectorUtils");
const corsHeaders = {
    'Access-Control-Allow-Origin': 'https://lucid.app',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Lucid-Signature, X-Lucid-RSA-Nonce',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400'
};
function dataConnectorHttpTrigger(request, context) {
    return __awaiter(this, void 0, void 0, function* () {
        context.log(`Data connector function processed request for url "${request.url}" with method "${request.method}"`);
        // Log query parameters, if any.
        if (request.query && Object.keys(request.query).length > 0) {
            context.log('Query parameters received:', request.query);
        }
        // Handle preflight OPTIONS request
        if (request.method.toUpperCase() === 'OPTIONS') {
            context.log('Received an OPTIONS preflight request. Returning CORS headers.');
            return {
                status: 204,
                headers: corsHeaders
            };
        }
        try {
            // Process and log request headers.
            context.log('Processing request headers.');
            // Convert Azure Functions headers to Record<string, string | string[]>
            const headers = {};
            request.headers.forEach((value, key) => {
                headers[key] = value;
            });
            context.log('Converted headers:', headers);
            // Read and log the request body.
            context.log('Attempting to read the request body.');
            // Get request body once
            const body = yield request.json();
            context.log('Request body received:', body);
            // Validate the request from Lucid.
            context.log('Validating Lucid request with provided headers and body.');
            yield (0, dataConnectorUtils_1.validateLucidRequest)(headers, body);
            context.log('Request validation succeeded.');
            // Create the data connector instance.
            context.log('Creating data connector instance.');
            const dataConnector = (0, dataConnectorUtils_1.createDataConnector)();
            // Log before executing the connector action.
            context.log('Executing data connector action.', { url: request.url, headers, body });
            const startTime = Date.now();
            // Execute action
            const response = yield dataConnector.runAction(request.url, headers, body);
            const elapsedTime = Date.now() - startTime;
            context.log(`Data connector action executed in ${elapsedTime} ms. Response status: ${response.status}`);
            // Log and return the final response.
            context.log('Returning response from data connector action.');
            return {
                status: response.status,
                jsonBody: response.body,
                headers: Object.assign(Object.assign({}, corsHeaders), { 'Content-Type': 'application/json' })
            };
        }
        catch (error) {
            context.error('Error in data connector action:', error);
            return {
                status: 500,
                jsonBody: { error: error.message },
                headers: Object.assign(Object.assign({}, corsHeaders), { 'Content-Type': 'application/json' })
            };
        }
    });
}
exports.dataConnectorHttpTrigger = dataConnectorHttpTrigger;
functions_1.app.http('dataConnector', {
    methods: ['GET', 'POST', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'dataConnector/{name}',
    handler: dataConnectorHttpTrigger
});
//# sourceMappingURL=dataConnectorHttpTrigger.js.map