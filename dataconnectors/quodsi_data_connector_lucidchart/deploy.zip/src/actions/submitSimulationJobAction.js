"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitSimulationJobAction = void 0;
const lucidSimulationJobSubmissionService_1 = require("../services/lucidSimulationJobSubmissionService");
const batchErrors_1 = require("../services/errors/batchErrors");
const submitSimulationJobAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    const metrics = {
        startTime: Date.now()
    };
    console.log('[submitSimulationJobAction] Starting execution');
    try {
        // Extract and validate request data
        const data = action.data;
        const { documentId, pageId, userId, applicationId, appVersion } = data;
        if (!documentId || !pageId || !userId) {
            console.error('[submitSimulationJobAction] Missing required fields', {
                hasDocumentId: !!documentId,
                hasPageId: !!pageId,
                hasUserId: !!userId
            });
            return { success: false };
        }
        console.log('[submitSimulationJobAction] Initializing batch service');
        // Initialize batch service with configuration from environment
        const batchService = new lucidSimulationJobSubmissionService_1.LucidSimulationJobSubmissionService({
            batchAccountUrl: process.env.BatchAccountUrl,
            batchAccountName: process.env.BatchAccountName,
            batchAccountKey: process.env.BatchAccountKey,
            poolId: process.env.BatchPoolId,
            defaultApplicationId: process.env.DefaultApplicationId,
            defaultAppVersion: process.env.DefaultAppVersion
        });
        console.log('[submitSimulationJobAction] Submitting job to batch service', {
            documentId,
            pageId,
            userId,
            applicationId,
            appVersion
        });
        // Submit the job
        const result = yield batchService.submitJob(documentId, pageId, userId, applicationId, appVersion);
        // Extract jobId and taskId from result message for logging
        const jobIdMatch = result.match(/Job '([^']+)'/);
        const taskIdMatch = result.match(/task '([^']+)'/);
        // Log performance metrics
        const totalDuration = Date.now() - metrics.startTime;
        console.log('[submitSimulationJobAction] Operation completed', {
            totalDuration: `${totalDuration}ms`,
            documentId,
            pageId,
            userId,
            jobId: jobIdMatch === null || jobIdMatch === void 0 ? void 0 : jobIdMatch[1],
            taskId: taskIdMatch === null || taskIdMatch === void 0 ? void 0 : taskIdMatch[1],
            result
        });
        return { success: true };
    }
    catch (error) {
        const errorDuration = Date.now() - metrics.startTime;
        if (error instanceof batchErrors_1.BatchConfigurationError) {
            console.error(`[submitSimulationJobAction] Batch configuration error after ${errorDuration}ms:`, {
                configurationKey: error.configurationKey,
                message: error.message
            });
        }
        else if (error instanceof batchErrors_1.BatchJobCreationError) {
            console.error(`[submitSimulationJobAction] Batch job creation error after ${errorDuration}ms:`, {
                jobId: error.jobId,
                batchError: error.batchError,
                message: error.message
            });
        }
        else {
            console.error(`[submitSimulationJobAction] Unexpected error after ${errorDuration}ms:`, {
                type: error.constructor.name,
                message: error instanceof Error ? error.message : 'Unknown error',
                stack: error instanceof Error ? error.stack : undefined
            });
        }
        return { success: false };
    }
});
exports.submitSimulationJobAction = submitSimulationJobAction;
//# sourceMappingURL=submitSimulationJobAction.js.map