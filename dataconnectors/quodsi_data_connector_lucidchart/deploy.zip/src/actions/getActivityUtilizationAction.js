"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getActivityUtilizationAction = void 0;
const lucidApi_1 = require("../services/lucidApi");
const config_1 = require("../config");
const getActivityUtilizationAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Type assertion to ensure action.data has the expected structure
        const data = action.data;
        // Extract data from action
        const { documentId, userId } = data;
        const authToken = action.context.userCredential;
        // Log for debugging
        console.log(`[getActivityUtilizationAction] Fetching activity utilization for document ID: ${documentId}`);
        // Get configuration
        const config = (0, config_1.getConfig)();
        // Create LucidApiService instance
        const baseUrl = config.apiBaseUrl;
        const lucidApiService = (0, lucidApi_1.createLucidApiService)(baseUrl);
        // Get the CSV blob
        const csvText = yield lucidApiService.getActivityUtilization(documentId, userId);
        console.log("[getActivityUtilizationAction] Successfully retrieved activity utilization data");
        return {
            status: 200,
            json: {
                csvData: csvText
            }
        };
    }
    catch (error) {
        console.error("[getActivityUtilizationAction] Error fetching activity utilization:", error);
        return {
            status: 500,
            json: {
                csvData: '',
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            }
        };
    }
});
exports.getActivityUtilizationAction = getActivityUtilizationAction;
//# sourceMappingURL=getActivityUtilizationAction.js.map