"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.simulateAction = void 0;
const lucidApi_1 = require("../services/lucidApi");
const config_1 = require("../config");
const simulateAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('[simulateAction] Starting simulateAction execution.');
    try {
        // Log the complete action received.
        console.log('[simulateAction] Received action:', action);
        // Perform a type assertion to ensure action.data has the expected structure.
        console.log('[simulateAction] Attempting type assertion on action.data.');
        const data = action.data;
        console.log('[simulateAction] Type assertion successful. Data extracted:', data);
        // Extract data from action
        const { documentId, pageId, userId } = data;
        const authToken = action.context.userCredential;
        console.log(`[simulateAction] Extracted documentId: ${documentId}, pageId: ${pageId}, userId: ${userId}`);
        // Log only the length of the auth token for security.
        console.log(`[simulateAction] Retrieved authToken (length: ${authToken ? authToken.length : 'undefined'})`);
        // Log the package ID and notify that the simulate action was triggered.
        console.log(`[simulateAction] Simulate action triggered for document ID: ${documentId} with package ID: ${action.context.packageId}`);
        // Retrieve configuration settings.
        console.log('[simulateAction] Retrieving configuration.');
        const config = (0, config_1.getConfig)();
        console.log('[simulateAction] Configuration retrieved:', config);
        // Create LucidApiService instance
        const baseUrl = config.apiBaseUrl;
        console.log(`[simulateAction] Creating LucidApiService with baseUrl: ${baseUrl}`);
        const lucidApiService = (0, lucidApi_1.createLucidApiService)(baseUrl);
        console.log('[simulateAction] LucidApiService instance created.');
        // Log details before calling the simulate endpoint.
        console.log('[simulateAction] Preparing to call simulateDocument endpoint with parameters:', {
            documentId,
            pageId,
            userId,
            authToken: authToken ? 'Provided' : 'Not Provided'
        });
        // Call the simulate endpoint using our service
        const success = yield lucidApiService.simulateDocument(documentId, pageId, userId, authToken);
        // Log the outcome of the simulateDocument call.
        console.log(`[simulateAction] simulateDocument response received: ${success}`);
        console.log(success
            ? "[simulateAction] Simulate action successfully triggered."
            : "[simulateAction] Simulate action failed.");
        console.log('[simulateAction] Exiting simulateAction execution.');
        return { success };
    }
    catch (error) {
        console.error("[simulateAction] Error executing simulate action:", error);
        return { success: false };
    }
});
exports.simulateAction = simulateAction;
//# sourceMappingURL=simulateAction.js.map