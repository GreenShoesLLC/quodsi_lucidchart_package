"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.importSimulationResultsAction = void 0;
const activityDataService_1 = require("../collections/activityDataService");
const importSimulationResultsAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log("=== Import Simulation Results Action Started ===");
        // Get the data from action.data with required pageId
        const data = action.data;
        if (!data.pageId) {
            throw new Error('pageId is required for import action');
        }
        // First, update the Models collection
        yield (0, activityDataService_1.updateModelData)(action, data.documentId, data.userId, data.pageId);
        // Then proceed with activity data update
        const result = yield (0, activityDataService_1.updateActivityData)(action, data.documentId, data.userId, 'import');
        console.log("=== Import Simulation Results Action Completed Successfully ===");
        return result;
    }
    catch (error) {
        console.error("=== Error in Import Simulation Results Action ===");
        console.error("Error details:", error);
        if (error instanceof Error) {
            console.error("Error name:", error.name);
            console.error("Error message:", error.message);
            console.error("Error stack:", error.stack);
        }
        return { success: false };
    }
});
exports.importSimulationResultsAction = importSimulationResultsAction;
//# sourceMappingURL=importSimulationResultsAction.js.map