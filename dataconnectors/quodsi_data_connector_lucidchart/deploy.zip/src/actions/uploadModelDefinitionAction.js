"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadModelDefinitionAction = void 0;
const azureStorageService_1 = require("../services/azureStorageService");
function getBlobName(userId, pageId) {
    return `model_${userId}_${pageId}.json`;
}
const uploadModelDefinitionAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    const metrics = {
        startTime: Date.now(),
        serializationDuration: 0,
        uploadDuration: 0
    };
    console.log('[uploadModelDefinitionAction] Starting execution');
    try {
        // Extract and validate request data
        const data = action.data;
        const { documentId, userId, pageId, model } = data;
        // Validate required fields
        if (!documentId || !userId || !pageId || !model) {
            console.error('[uploadModelDefinitionAction] Missing required fields', {
                hasDocumentId: !!documentId,
                hasUserId: !!userId,
                hasPageId: !!pageId,
                hasModel: !!model
            });
            return { success: false };
        }
        // Initialize storage service
        const connectionString = process.env.AzureStorageConnectionString;
        if (!connectionString) {
            console.error('[uploadModelDefinitionAction] Storage connection string is not configured');
            throw new Error('Storage connection string is not configured');
        }
        const storageService = new azureStorageService_1.AzureStorageService(connectionString);
        // Prepare the model JSON
        const serializeStart = Date.now();
        const modelJson = JSON.stringify(model, null, 2);
        metrics.serializationDuration = Date.now() - serializeStart;
        // Upload the model
        const uploadStart = Date.now();
        const blobName = getBlobName(userId, pageId);
        console.log(`[uploadModelDefinitionAction] Uploading model to blob storage`, {
            documentId,
            blobName,
            modelSize: modelJson.length
        });
        const uploadSuccess = yield storageService.uploadBlobContent(documentId, blobName, modelJson);
        metrics.uploadDuration = Date.now() - uploadStart;
        if (!uploadSuccess) {
            console.error('[uploadModelDefinitionAction] Failed to upload model definition');
            return { success: false };
        }
        // Log performance metrics
        const totalDuration = Date.now() - metrics.startTime;
        console.log('[uploadModelDefinitionAction] Operation completed', {
            totalDuration: `${totalDuration}ms`,
            serializationDuration: `${metrics.serializationDuration}ms`,
            uploadDuration: `${metrics.uploadDuration}ms`,
            modelSize: modelJson.length,
            blobUrl: `${documentId}/${blobName}`,
            uploadDateTime: new Date().toISOString()
        });
        return { success: true };
    }
    catch (error) {
        const errorDuration = Date.now() - metrics.startTime;
        console.error(`[uploadModelDefinitionAction] Error after ${errorDuration}ms:`, {
            type: error.constructor.name,
            message: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined
        });
        return { success: false };
    }
});
exports.uploadModelDefinitionAction = uploadModelDefinitionAction;
//# sourceMappingURL=uploadModelDefinitionAction.js.map