"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pollAction = void 0;
const activityDataService_1 = require("../collections/activityDataService");
const contextHelper_1 = require("../utils/contextHelper");
const pollAction = (action) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log("=== Poll Action Started ===");
        // Get validated context data
        const context = (0, contextHelper_1.getRequiredContext)(action);
        // If no context found, return success without doing anything
        if (!context) {
            console.log("No valid context found, skipping poll update");
            return { success: true };
        }
        // Use the shared activity data service
        const result = yield (0, activityDataService_1.updateActivityData)(action, context.documentId, context.userId, 'poll');
        console.log("=== Poll Action Completed Successfully ===");
        return result;
    }
    catch (error) {
        console.error("=== Error in Poll Action ===");
        console.error("Error details:", error);
        if (error instanceof Error) {
            console.error("Error name:", error.name);
            console.error("Error message:", error.message);
            console.error("Error stack:", error.stack);
        }
        return { success: false };
    }
});
exports.pollAction = pollAction;
//# sourceMappingURL=pollAction.js.map