"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
functions_1.app.setup({
    enableHttpStream: true,
});
require("./functions/dataConnectorHttpTrigger");
require("./functions/getDocumentStatus");
require("./functions/httpTrigger1");
require("./functions/saveAndSubmitSimulation");
require("./functions/submitSimulationJob");
require("./functions/uploadModelDefinition");
//# sourceMappingURL=index.js.map