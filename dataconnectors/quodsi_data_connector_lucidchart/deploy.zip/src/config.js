"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfig = void 0;
const config = {
    apiBaseUrl: process.env.QUODSI_API_URL || 'http://localhost:5000/api/',
    batchAccountName: process.env.BATCH_ACCOUNT_NAME || '',
    batchAccountKey: process.env.BATCH_ACCOUNT_KEY || '',
    batchAccountUrl: process.env.BATCH_ACCOUNT_URL || ''
};
function getConfig() {
    return config;
}
exports.getConfig = getConfig;
//# sourceMappingURL=config.js.map